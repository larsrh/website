#!/bin/bash
set -e
STATUS="$(hg prompt '{status}')"

if [ -z "$STATUS" ]; then
  ID="$(hg id -i)"
  FILE="esop2018_submission2_rev$ID.zip"
  echo "Writing to $FILE"
  hg archive -t zip "$FILE"
else
  echo "Dirty, exiting"
  exit 1
fi
