# README #

How to build these theories:

1. Obtain Isabelle and the AFP (version 2017).
2. Register the AFP as a component in Isabelle by adding a line `/path/to/afp-2017` to the file `~/.isabelle/Isabelle2017/etc/components`.
3. In the root of this repository, run `isabelle build -bv -d . -d '$AFP' Reify_Test`.
4. Start Isabelle/jEdit with `isabelle jedit -d . -d '$AFP' -l CakeML_Extras`.

How to build the documentation:

1. Go to the `doc` folder.
2. Run `latexmk -pdf report.tex`.
